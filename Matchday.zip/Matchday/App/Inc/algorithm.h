#ifndef _ALGORITHM_H__
#define _ALGORITHM_H__

#include "Init.h"

extern int HalfThre(uint8 img[ROW][COL],int cLimit);
extern int Average(uint8 data[],int start,int end); 
extern double GetOffset(Point *A,Point *B,Point *C);
extern double Pslop(Point *point1,Point *point2,uint8 unY);

#endif