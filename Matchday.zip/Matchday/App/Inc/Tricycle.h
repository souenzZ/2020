#ifndef _TRICYCLE_H_
#define _TRICYCLE_H_
extern void Data_Filter();
extern void tricycle();
extern void I2C_get();
extern void Speed_Control(void);
extern void Speed_Control_Output(void);

extern float  Turn_Out_Filter(float turn_out);    //ת���������˲� 
#define KP 0
#define KI 1
#define KD 2
#define KT 3
#define KB 4
#define KF 5

typedef struct PID
{
	float SumError;	//����ۼ�	
	int32 LastError;	//Error[-1]
	int32 PrevError;	//Error[-2]	
	int32 LastData;	//Speed[-1]
} PID;



int32 PlacePID_Control(PID *sprt, float *PID, int32 NowPiont, int32 SetPoint);

extern float   Direct[4], Turn[4];
extern float outnew;
extern float Td;
extern int32 Radius;

extern PID  Direct_PID, Turn_PID;

#endif