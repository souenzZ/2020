#ifndef __PICTURE_H__
#define __PICTURE_H__

#include "common.h"
#include "include.h"

extern uint8 tmpImg[ROW][COL];
extern void DetectionStop(uint8 img[ROW][COL]);
extern void LineProcess();

#endif