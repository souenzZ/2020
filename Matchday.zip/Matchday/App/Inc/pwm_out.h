#ifndef _PWM_OUT_H_
#define _PWM_OUT_H_
extern void Motor_Lock(float motorR_ideal_speed,float motorL_ideal_speed);

extern int motorR_ideal_speed ;
extern int motorL_ideal_speed ;
#endif  