#ifndef _COMMON_DATA_H_
#define _COMMON_DATA_H_

#define Gyro_VAL_Y                  -2 //��������ֵ ת��



//��־λ
extern float stopflag;
extern int gogogo;
extern int  stopCarFlag;	//ͣ����־
extern int stopOk;
extern int motor;
extern int motorLock;
extern int carInBoxErro;
extern int controlAddPID;
extern int leftSpeed;
extern int rightSpeed;
//Բ��
extern int ring1,ring2,zring,ringg,dring;
//�ж�
extern int S_time; 
extern int Flag_time200,Flag_time;
//��Ų���
extern int addata[4];
extern int value[4];
extern uint16 ADvalue[4];
extern int ADvaluex0,ADvaluex1,ADvaluey0,ADvaluey1,ADvaluez0,ADvaluez1,ADvalueh0,ADvalueh1;
extern int adsum[5];
extern int avalue[5][5];
extern int maxvalue[4];
extern int minvalue[4];
extern int ADMAX[4];
extern int ADMIN[4];   //��Сֵ����
extern float d1,d2,d3;
extern float SUM,SUM1,SUM2,SUM3;
extern float erro;
//�������
extern float Left_PWM;
extern float Right_PWM;
extern int Speed_L;
extern int Speed_R;
extern int L_inf_Out,R_inf_Out;    //������
//�ٶ�
extern int Right_Pulse,Left_Pulse;
extern float R_speed,L_speed;
extern float Rout,Lout;
extern float now_speed,R_speed,L_speed;
extern float i_speed;
extern float SpeedControlIntegral;
extern float SpeedControlOutNew;
extern float SpeedControlOutOld;
extern float Speed_OUT;
extern float SpeedCount;
extern float SPEED_P,SPEED_I;

//�Ƕ�
extern int16 mpu_gyro_x,mpu_gyro_y,mpu_gyro_z;
extern int32 mpu_acc_x,mpu_acc_y,mpu_acc_z;
extern float gyrox,gyroy,gyroz,accx,accy,accz;
extern int32 ACC_X_BUF[5], ACC_Y_BUF[5], ACC_Z_BUF[5];	// �˲���������
extern int32 GYRO_X_BUF[1], GYRO_Y_BUF[1], GYRO_Z_BUF[1];
//����ͷ
extern int valueT;     //��ֵ
extern int leftStart,rightEnd;     // ���Ҽ����ʼ������
extern int upStart,underEnd;     // ͼ�����¼����ʼ������  35---45       20---30  12---22
extern int judgeDirection;
//���
extern int turn;	
extern int turn_angle;    
extern int Speed;  	   
extern int oneStep; 
extern int twoStep; 
extern int distance;

#endif