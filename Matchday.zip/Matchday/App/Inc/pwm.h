#ifndef _PWM_H_
#define _PWM_H_
extern void Motor_Calculate(void);
extern void Motor_Output(void);
#endif