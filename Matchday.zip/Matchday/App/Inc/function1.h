#ifndef _FUNCTION1_H_
#define _FUNCTION1_H_

typedef struct
{ 
    int16 flag;
    int16 stage;
    float leftDistence;
    float rightDistence;
    float distence;
    int16 judgeTime;
}EnterTheGarage;

extern EnterTheGarage inGarage;

extern void MechanicalStorage (void);	
extern void sueque1 (int datas[5],int new_data);
extern void average1(void);
extern void get_magnetic1(void);
extern void MechanicalStorageTwo (void);

#endif