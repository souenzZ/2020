#ifndef _READ_SPEED_H
#define _READ_SPEED_H
extern void pulse_init(void);
extern void read_speed(void);
#endif  