#ifndef _ISR_H_
#define _ISR_H_

extern void PIT0_IRQHandler(void);
extern void PORTC_IRQHandler(void);
extern void DMA0_IRQHandler(void);
extern void uart3_handler(void);
extern void URAT5_Handler(void);
extern int time8s;


#endif