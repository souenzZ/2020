#include "include.h"
#include "pwm_out.h"
#include "function1.h"

void Motor_Calculate(void)
{  
  if(stopflag)
   { 
      Speed_L=0;
      Speed_R=0;
    }
  else if(gogogo==1)
    {
       Speed_L = (int)(Speed_OUT+1*Td);
       Speed_R = (int)(Speed_OUT-1*Td);

    }
  else 
    {    
       Speed_L = (int)(0+0*Td);
       Speed_R = (int)(0-0*Td);
    }
  
//  //��⡤
//    if( 1 == stopCarFlag && stopOk == 0) 
//    {
//        MechanicalStorage();
//        if(( inGarage.stage ==  0 || inGarage.stage ==2 ) && motor == 0)
//        {
//            Speed_L = (int)L_inf_Out;
//            Speed_R = (int)R_inf_Out;
//        }
//    }
  
  
  if( 1 == controlAddPID ){
        Motor_Lock(leftSpeed,rightSpeed);      // 16---7	
  }
    // ����ͣ
  if( 1 == motorLock ){
       Motor_Lock(0,0);		//�������
  }
  
  
    
}
void Motor_Output(void)
{  /***********************������ٶ�����******************************/
    if(Speed_L > 9999)  Speed_L = 9999;
    if(Speed_L < -9999) Speed_L = -9999;
    if(Speed_R > 9999)  Speed_R = 9999;
    if(Speed_R < -9999) Speed_R = -9999;
//**********************��������*********************************
   if(Speed_L >= 0)
    {
        ftm_pwm_duty(FTM0,FTM_CH6,(uint32)(Speed_L ));  ///��ǰ
        ftm_pwm_duty(FTM0,FTM_CH5,0);  ///����
    }
      else
    {
        ftm_pwm_duty(FTM0,FTM_CH6,0);  ///��ǰ
        ftm_pwm_duty(FTM0,FTM_CH5,(uint32)(-Speed_L ));  ///����
    }
    if(Speed_R >= 0)
    {
         ftm_pwm_duty(FTM0,FTM_CH3,(uint32)(Speed_R ));//��ǰ
         ftm_pwm_duty(FTM0,FTM_CH4,0);//����
    }
    else
    {
        ftm_pwm_duty(FTM0,FTM_CH4,(uint32)(-Speed_R ));//����
        ftm_pwm_duty(FTM0,FTM_CH3,0);
    }

}
  