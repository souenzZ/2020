#include "include.h"
#include "common.h"
#include "isr.h"
int time8s;
int s;
void PIT0_IRQHandler(void)
{  
     S_time > 60000 ? 60000 : S_time++ ;  
     
     if(time8s<2)
     {time8s++;}
     else 
     {time8s=0;}
     
      I2C_get();
      Data_Filter();
      
      get_magnetic1(); 
             
      read_speed(); 
              
//        if( time8s==1 ){
//          Radius = PlacePID_Control ( &Turn_PID , Turn , (int)erro , 0);	    }// ��̬PID����ת��
if(gogogo==1)      
{
  tricycle();


    Speed_Control();
    Speed_Control_Output();
     
      
} 

     
     
    if( Flag_time == 1 )
    {
        s++;
        if( s >= 100 ) 
        {
            s = 0;
            Flag_time = 0;
            Flag_time200 = 1;
        }
    }
//     
      if( S_time >= 150 && gogogo == 1)
      {
        Motor_Calculate();  
        Motor_Output();    
      }

      
    PIT_Flag_Clear(PIT0);    
}



//�������ã��Ƚ��ַ���
//�������ַ�����ͬʱ������ֵΪ0
int strcmp(const char* str1, const char* str2)
{
	while ((*str1) && (*str1 == *str2))
	{
		str1++;
		str2++;

	}
	if (*(unsigned char*)str1 > *(unsigned char*)str2)
	{
		return 1;
	}
	else if (*(unsigned char*)str1 < *(unsigned char*)str2)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}

char ch[9];
char str[8] = "_abc123_";
static int num;
void URAT5_Handler(void)
{
  uart_getchar (UART5,&ch[num++]);
  if(ch[0] != 0x23 ) num = 0;
  if(num == 9 ){
//    ch[9] = '\0';
    if(0 == strcmp(&ch[1],str)){
        gpio_set (PTE10,1);
        gogogo = 1;
        uart_rx_irq_dis(UART5);         
    }
    num = 0;
  }
  

  
}



void uart3_handler(void)
{
  UARTn_e uratn = UART3;
  if(UART_S1_REG(UARTN[uratn]) & UART_S1_RDRF_MASK) //�������ݼĴ�����
  {
    mt9v032_cof_uart_interrupt();
  }
}

void DMA0_IRQHandler(void)
{
  DMA_IRQ_CLEAN(MT9V032_DMA_CH);
  DMA_EN(MT9V032_DMA_CH);
  row_finished();
}


void PORTC_IRQHandler(void)
{
  uint8 n=6;
  if(PORTC_ISFR & (1 << n))           //PTC18 �����ж�
  {
    PORTC_ISFR = (1 << n);        //д1���жϱ�־λ
    VSYNC();
  }
}