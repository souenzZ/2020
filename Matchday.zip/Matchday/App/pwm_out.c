#include "common.h"
#include "include.h"
#include "isr.h"
#include "pwm_out.h"

#define MAX_PWM         +9999
#define MIN_PWM         -9999

#define MAX_SPEED       +20000          //����ٶ�200
#define MIN_SPEED       -20000

#define MULTIPLE         1.8            //ֱ���ٶȱ���

float Lim;
float Temp_Lim;

int motorL_ek[3];
int motorR_ek[3];
int motorL_out;
int motorR_out;
int motorL_I_speed[2];
int motorR_I_speed[2];
int motorR_ideal_speed;
int motorL_ideal_speed;

float Temp_motorL_MP;
float Temp_motorR_MP;
float Temp_motorL_MI;
float Temp_motorR_MI;

float  motorL_MP = 220;      //����     //  170
float  motorL_MI = 440;                 //  220 

float  motorR_MP = 110;      //����     //  150   
float  motorR_MI = 240;                 //  220   

int Count_1, Temp_ideal_speed;

void Motor_Lock(float motorL_ideal_speed,float motorR_ideal_speed)
{
    
	if( motorR_ideal_speed > MAX_SPEED )   motorR_ideal_speed = MAX_SPEED;         //�ٶ�����  
	if( motorR_ideal_speed < MIN_SPEED )   motorR_ideal_speed = MIN_SPEED;           

	if( motorL_ideal_speed > MAX_SPEED )   motorL_ideal_speed = MAX_SPEED;		
	if( motorL_ideal_speed < MIN_SPEED )   motorL_ideal_speed = MIN_SPEED;

	static int motorLduty, motorLlast_duty=0;
	static float ProportionL, IntegralL;        //PI     
	motorL_ek[2] = motorL_ek[1];
	motorL_ek[1] = motorL_ek[0];
	motorL_ek[0] = (int)(motorL_ideal_speed - L_speed);

	ProportionL = (motorL_ek[0] - motorL_ek[1]) * motorL_MP;
	IntegralL   = (motorL_ek[0] * motorL_MI) / 10.0f;   

	motorLduty = (int)(ProportionL + IntegralL);

	/*-----------�����������ֿ�����-------------*/
	if (motorLlast_duty >= MAX_PWM)	if (motorLduty > 0) motorLduty = 0;
	if (motorLlast_duty <= MIN_PWM)	if (motorLduty < 0) motorLduty = 0;
	motorL_out += motorLduty;
	if (motorL_out >= MAX_PWM)      motorL_out = MAX_PWM;
	if (motorL_out <= MIN_PWM)      motorL_out = MIN_PWM;
	motorLlast_duty   = motorLduty;
	motorL_I_speed[1] = (int)motorL_ideal_speed;
	Speed_L = (int)(motorL_out);                								//������

	static int motorRduty, motorRlast_duty=0;
	static float ProportionR, IntegralR;        //PI
	motorR_ek[2] = motorR_ek[1];
	motorR_ek[1] = motorR_ek[0];
	motorR_ek[0] = (int)(motorR_ideal_speed - R_speed);

	ProportionR = (motorR_ek[0] - motorR_ek[1]) * motorR_MP;
	IntegralR   = (motorR_ek[0] * motorR_MI) / 10.0f;   

	motorRduty = (int)(ProportionR + IntegralR);

	/*-----------�����������ֿ�����-------------*/
	if (motorRlast_duty >= MAX_PWM)	if (motorRduty > 0) motorRduty = 0;
	if (motorRlast_duty <= MIN_PWM)	if (motorRduty < 0) motorRduty = 0;
	motorR_out += motorRduty;
	if (motorR_out >= MAX_PWM)      motorR_out = MAX_PWM;
	if (motorR_out <= MIN_PWM)      motorR_out = MIN_PWM;
	motorRlast_duty   = motorRduty;
	motorR_I_speed[1] = (int)motorR_ideal_speed;
	Speed_R = (int)(motorR_out); 
}