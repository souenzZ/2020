#include "include.h"
#include "function1.h"

EnterTheGarage inGarage;
void LRing();
void RRing();
void sueque1(int datas[5],int new_data)//�����˲�//7
{
  int i;
  for(i=4;i>0;i--)  datas[i]=datas[i-1];//6
  datas[0]=new_data;
}

void average1(void)
{
  int  i,j;

   /*����ź�*/
   ADvaluex0 =  adc_once (ADC0_SE14,ADC_12bit);//  X���    
   ADvaluex1 =  adc_once (ADC0_SE8,ADC_12bit);//  X�ұ�     
   ADvaluey0 =  adc_once (ADC1_SE15,ADC_12bit);//  �ұ�    
   ADvaluey1 =  adc_once (ADC0_SE12,ADC_12bit);//  ���

   ADvalue[0]=ADvaluex0;         
   ADvalue[1]=ADvaluex1;  
   ADvalue[2]=ADvaluey0;                  
   ADvalue[3]=ADvaluey1;  

 for(j=0;j<4;j++)// 0 1 2 3 װ4��
  {
    adsum[j]-=avalue[j][4];
    sueque1(avalue[j],ADvalue[j]);
    adsum[j]+=ADvalue[j];
    minvalue[j]=maxvalue[j]=avalue[j][0];
    for(i=0;i<5;i++)//0 1 2 3 4 
    {
      if(avalue[j][i]>maxvalue[j])        maxvalue[j]=avalue[j][i];
      else if(avalue[j][i]<minvalue[j])   minvalue[j]=avalue[j][i];
    }
    value[j]=(int)(adsum[j]-maxvalue[j]-minvalue[j])/3;
  }
}
//��ȡ��ǰ����ź�
void get_magnetic1(void)
{
  int i;
  int dx;
  average1();
//  findmax();
  //-----------------------------------------
  for(i=0;i<4;i++)              //��һ 0��1000
  {
     if(value[i]>ADMAX[i])        value[i]=ADMAX[i];
     else
     if(value[i]<ADMIN[i])        value[i]=ADMIN[i];
     dx=value[i]-ADMIN[i];
     dx=(dx*1000);
     dx=dx/((ADMAX[i]-ADMIN[i]));

     addata[i]=dx;
  }

    d1=addata[0]-addata[1];
    SUM1=addata[0]+addata[1];

    d2=addata[2]-addata[3];
    SUM2=addata[2]+addata[3];

    // ���
    if( 1 == stopCarFlag && stopOk == 0 ){
//      motorLock = 1;
      MechanicalStorageTwo();
    }
    
    else if((SUM1+SUM2)!=0)
    {
      erro = (((float)(d1+d2) / ((float)(SUM1+SUM2)) * 100));
    } 
    else 
        erro = 0;
    
    
      if(dring==1)
        {LRing();}
      else 
        {RRing();}
}



void LRing()// ��Բ��
{

  if(ADvalue[0]>3000&&ADvalue[1]>3000&&(ADvalue[2]<1000||ADvalue[3]<1000)&&ringg==0)
    {ringg=1;zring=1;}
  if(ringg==1)
    {
      if(zring==1||zring==2){ 
  erro=((float)(((addata[0]*1.3-addata[1]*0.7)+d2*1)/((addata[0]*1.3+addata[1]*0.7)+SUM2*1)))*200;}
      
      if(ADvalue[0]<2200&&ADvalue[1]<2200&&zring==1)
        {zring=2;}
      /***********************************/
      if(zring==2&&ADvalue[0]>3000&&ADvalue[1]>3000)
        {zring=3;}
      if(zring==3)
        {         
           erro=((float)(d1+d2)/(SUM1+SUM2))*200;
           gpio_set(PTE10,1);
          if(ADvalue[2]<800||ADvalue[3]<800)
          { 
            if(addata[0]>=addata[1]) erro=((float)(addata[0]*0.5-addata[1]*1.5)/(SUM1))*100;
            if(addata[0]<addata[1])  erro=((float)(addata[0]*1.5-addata[1]*0.5)/(SUM1))*100; 
          }
          if(ADvalue[2]<700&&ADvalue[3]<700&&(ADvalue[0]<1800&&ADvalue[1]<1800))
            {zring=0;ringg=0;ring2=0;gpio_set(PTE10,0);}
        }
    }
}


void RRing()//�һ���
{
  if(ADvalue[0]>3100&&ADvalue[1]>3100&&(ADvalue[2]<1000||ADvalue[3]<1000)&&ringg==0)
    {ringg=1;zring=1;}
  if(ringg==1)
    {
      if(zring==1||zring==2)
          {erro=((float)(((addata[0]*0.65-addata[1]*1.35)+d2*1)/((addata[0]*0.65+addata[1]*1.35)+SUM2*1)))*180;}
      
      
      if(ADvalue[0]<2200&&ADvalue[1]<2200&&zring==1)
        {zring=2;}
      
      
      if(zring==2&&ADvalue[0]>2400&&ADvalue[1]>2400)
        {zring=3;}
      if(zring==3)
        {
            erro=((float)(d1+d2)/(SUM1+SUM2))*200;
            gpio_set(PTE10,1);
          if(ADvalue[2]<800||ADvalue[3]<800&&ADvalue[0]>3000&&ADvalue[1]>3000)
          { 
            if(addata[0]>=addata[1]) erro=((float)(addata[0]*0.6-addata[1]*1.4)/(SUM1))*100;
            if(addata[0]<addata[1]) erro=((float)(addata[0]*1.4-addata[1]*0.6)/(SUM1))*100; 
          }
          if(ADvalue[2]<400&&ADvalue[3]<400&&(ADvalue[0]<2000&&ADvalue[1]<2000))
            {zring=0;ringg=0;gpio_set(PTE10,0);}
        }
    }
}
/**********************************************************************************************/
void MechanicalStorage (void)			
{
      if( stopCarFlag == 1 && inGarage.stage == 0)		//ͣ����ת��׼��������
      {	 
        Flag_time = 1;
        motor = 1;
        Motor_Lock(0,0);		//�������
        if(Flag_time200 == 1){
            motor = 0;
            L_inf_Out = Speed;
            R_inf_Out = Speed;
            inGarage.leftDistence += ABS(L_speed);//ABS(ftm_quad_get(FTM1)); 
            inGarage.rightDistence += ABS(R_speed);//ABS(ftm_quad_get(FTM2)); 
            inGarage.distence = (int)(( inGarage.leftDistence + inGarage.rightDistence ) / 2);
            if( inGarage.distence >= oneStep )
            {
                inGarage.stage = 1;
                inGarage.leftDistence = 0;      //��ֹ ǰ���ϰ����� δ��
                inGarage.rightDistence = 0;
                inGarage.distence =0;
                L_inf_Out = 0;
                R_inf_Out = 0;
                
                Flag_time200 = 0;
            }
        } 
    }
    if( inGarage.stage == 1 )		
    {
        
        Flag_time = 1;
        Motor_Lock(0,0);		//�������
        if(Flag_time200 == 1){
            
            Motor_Lock(turn,-turn);		//�������
            
            inGarage.leftDistence += ABS(L_speed);//ABS(ftm_quad_get(FTM1)); 
            inGarage.rightDistence += ABS(R_speed);//ABS(ftm_quad_get(FTM2));
            inGarage.distence = (int)(( inGarage.leftDistence + inGarage.rightDistence ) / 2);
            if( inGarage.distence >= turn_angle )
            {
                inGarage.stage = 2;
                inGarage.leftDistence = 0;      //��ֹ ǰ���ϰ����� δ��
                inGarage.rightDistence = 0;
                inGarage.distence =0;
                
                Flag_time200 = 0;
               
            }   
        }
    }
      
    if(inGarage.stage == 2 )		
	{  
        L_inf_Out = Speed;
        R_inf_Out = Speed;
        inGarage.leftDistence += ABS(L_speed);//ABS(ftm_quad_get(FTM1)); 
        inGarage.rightDistence += ABS(R_speed);//ABS(ftm_quad_get(FTM2));
        inGarage.distence = (int)(( inGarage.leftDistence + inGarage.rightDistence ) / 2);
        if( inGarage.distence >= twoStep )
        {
            inGarage.stage = 0;
            inGarage.leftDistence = 0;      //��ֹ ǰ���ϰ����� δ��
            inGarage.rightDistence = 0;
            inGarage.distence =0;
            L_inf_Out = 0;
            R_inf_Out = 0;
            
            Flag_time200 = 0;
            
            stopOk = 1;
            stopflag=1;
        }
	}
      
}

/**********************************************************************************************/
 void MechanicalStorageTwo (void){
    
    inGarage.leftDistence += ABS(L_speed);//ABS(ftm_quad_get(FTM1)); 
    inGarage.rightDistence += ABS(R_speed);//ABS(ftm_quad_get(FTM2));
    inGarage.distence = (int)(( inGarage.leftDistence + inGarage.rightDistence ) / 2);

    if (inGarage.distence < distance)
    {	 
//        erro = carInBoxErro ;
         controlAddPID = 1;
    }
//    else if (inGarage.distence <= 4000)
//    {     
//        controlAddPID = 0;
//        erro  = 0;
//    } 
    else{
        
        inGarage.stage = 0;
        inGarage.leftDistence = 0;      //��ֹ ǰ���ϰ����� δ��
        inGarage.rightDistence = 0;
        stopOk = 1;
        motorLock = 1;
        
        controlAddPID = 0;
        
    }
}

