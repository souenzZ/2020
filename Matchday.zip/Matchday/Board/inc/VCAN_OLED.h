#ifndef __OLED_H
#define __OLED_H			  	 
//#include "sys.h"

#define uint unsigned int;
#define byte uint8;



#define OLED_CMD  0	//D��?����?
#define OLED_DATA 1	//D�䨺y?Y
//OLED????��?o����y
void OLED_WR_Byte(uint8 dat,uint8 cmd);	    
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Refresh_Gram(void);		   				   		    
void OLED_Init(void);
void OLED_Clear(void);
void OLED_DrawPoint(uint8 x,uint8 y,uint8 t);
void OLED_ShowChar(uint8 x,uint8 y,uint8 chr,uint8 size,uint8 mode);
void OLED_ShowNumber(uint8 x,uint8 y,uint32 num,uint8 len,uint8 size);
void OLED_ShowString(uint8 x,uint8 y,const uint8 *p);
void  LCD_Print(uint8 x, uint8 y, uint8 ch[]);
void  LCD_P14x16Str(uint8 x,uint8 y,uint8 ch[]);
void oled_show(void);
void LED_P6x8Char(char x,char  y,char ch);
void OLED_WrDat(uint8 data) ;
void LED_PrintBMP(uint8 x0,uint8 y0,uint8 x1,uint8 y1,char bmp[]);
extern  const char F6x8[][6];



#endif  
	 